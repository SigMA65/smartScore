#include "orgStruct.h"

#include "orgStructDb.h"

#include <QtDebug>
#include <QMessageBox>

//OrgStruct::OrgStruct() :
//    QObject(parent)
//{
//}

void OrgStruct::addBranch(const OrgStructBranch branch)
{
//    if (orgStructList.isEmpty())
//            orgStructList = new QList<OrgStructBranch>;
    orgStructList.append(branch);
}

void OrgStruct::updateBranch(const OrgStructBranch branch)
{
    quint32 id = branch._id;

    /*// ������������� �������������
    OrgStructBranch eb = findBranchById(id);
    if (!eb) {
        eb = branch;
    } else {
        QString txt =
              QString(QObject::tr("�� ������� ������������� � Id=%1")).arg(id);
        QMessageBox::critical(0, QObject::tr("������"), txt, QMessageBox::Ok);
    }*/

    QMutableListIterator<OrgStructBranch> itr(orgStructList);

    while (itr.hasNext()) {
        if (itr.next()._id == id) {
            itr.setValue(branch);
//            qDebug() << "OrgStruct::updateBrunch " <<  id << "   " << itr.value().nameFull << "   " << itr.value().nameShort;
        }
    }

}

void OrgStruct::newBranch(OrgStructBranch &branch)
{
    branch.setId(getNextId());
    addBranch(branch);
}

void OrgStruct::deleteBranch(quint32 id)
{
//    qDebug() << "OrgStruct::deleteBranch";
    QList<OrgStructBranch>::iterator i = findBranchById(id);
    if (i != orgStructList.end()) {
        orgStructList.erase(i);
    } else {
        qDebug() << "OrgStruct::deleteBranch !!!!!!!!!!!!!!!" <<
                    QObject::tr("�� ������ ������������� ") << id;
    }
}

//TODO:* I don't know what to do with this
//QMutableListIterator<OrgStructBranch> OrgStruct::findBranchById(quint32 id)
QList<OrgStructBranch>::iterator OrgStruct::findBranchById(quint32 id)
{
/*
//    qDebug() << "OrgStruct::findBranchById ENTRY";

    QMutableListIterator<OrgStructBranch> itr(orgStructList);
    while (itr.hasNext()) {
        if (itr.next()._id == id) {
//            qDebug() << "OrgStruct::findBranchById " <<  id << "   " << itr.value().nameFull;
//            const OrgStructBranch b(2, 1, "3333333333");
//            itr.setValue(b);
//            qDebug() << "OrgStruct::findBranchById " <<  id << "   " << itr.value().nameFull;
            return itr;
        }
    }
//    return itr
*/
    QList<OrgStructBranch>::iterator i;
    for (i = orgStructList.begin(); i != orgStructList.end(); ++i) {
        if (((OrgStructBranch)*i)._id == id) {
            return i;
        }
    }
    return orgStructList.end();
}

QList<OrgStructBranch> OrgStruct::getOrgStructList()
{
    return orgStructList;
}

void OrgStruct::clearOrgStructList()
{
    orgStructList.clear();
//    qDebug() << countBranches();
}

quint16 OrgStruct::countBranches()
{
    return orgStructList.count();
}

void OrgStruct::printDebugList()
{
    qDebug() << QObject::tr("� ������ ") << countBranches() << QObject::tr(" �������������");
   foreach(OrgStructBranch branch, orgStructList)
    {
        qDebug()<<branch._id<<branch.nameFull;
    }
    qDebug() << "\n";
}

void OrgStruct::saveOrgStructList() {
    OrgStructDb::saveList(orgStructList);
}

void OrgStruct::readOrgStructList()
{
    OrgStructDb::readList(orgStructList);
    calcMaxId();
}

void OrgStruct::calcMaxId()
{
    maxId = 0;
    foreach (OrgStructBranch b, orgStructList) {
        maxId = maxId < b._id ? b._id : maxId;
    }
    qDebug() << "OrgStruct::calcMaxId " << "maxId=" << maxId;
}

OrgStructBranch::OrgStructBranch(quint32 p_id,
                                 quint32 p_parentId,
                                 const QString &p_nameFull,
                                 const QString &p_nameShort,
                                 const QString &p_note)
{

    _id = p_id;
    parentId = p_parentId;
    nameFull = p_nameFull;
    nameShort = !p_nameShort.isEmpty() ? p_nameShort : p_nameFull;
    _note = p_note;

    _flag = old;

    qDebug() << "OrgStructBranch::OrgStructBranch =>" << "p_nameFull=" << p_nameFull << " p_nameShort=" << p_nameShort <<
                " nameShort=" << nameShort;

}

OrgStructBranch::OrgStructBranch(quint32 p_parentId, FlagFresh flag)
{
    parentId = p_parentId;
    _flag = flag;

    if (_flag == OrgStructBranch::newHead) {
        _id = parentId; // ���� ��� �������� �����������, �� ���������
    }
}




