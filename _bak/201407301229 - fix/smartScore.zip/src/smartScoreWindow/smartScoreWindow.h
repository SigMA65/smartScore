#ifndef SMARTSCOREWINDOW_H
#define SMARTSCOREWINDOW_H

#include <QMainWindow>

class CentralWorkSpace;

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    CentralWorkSpace *centralWorkSpace;

};

#endif // SMARTSCOREWINDOW_H
