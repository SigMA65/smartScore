#include "smartScoreWindow.h"
#include "centralWorkSpace.h"
//#include "orgStruct.h"

#include <QtGui>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    qDebug() << "MainWindow::MainWindow START";

    setWindowTitle(tr("SmartScore 0.1"));

    centralWorkSpace = new CentralWorkSpace(Qt::Horizontal);
    setCentralWidget(centralWorkSpace);

    statusBar()->showMessage("111111111111111111111111");

    qDebug() << "MainWindow::MainWindow END";
}

MainWindow::~MainWindow()
{
    
}
