#include "orgStruct.h"
#include "orgStructDb.h"
#include "../common/common.h"

#include <QString>
#include <QFile>
#include <QDataStream>

const QString OrgStructDb::dbFileName = QString("orgStruct.data");

OrgStructDb::OrgStructDb()
{
}

void OrgStructDb::saveList(const QList<OrgStructBranch> &list)
{
    QString fileName = dbDir + "/" + dbFileName;
    QFile file(fileName);
    file.open(QFile::WriteOnly);
    QDataStream out(&file);
    out.setVersion(QDataStream::Qt_4_8);

    out << list;
    file.flush();
    file.close();

//    foreach (OrgStructBranch branch, list) {
//        out << branch;
    //    }
}

void OrgStructDb::readList(QList<OrgStructBranch> &list)
{
    QString fileName = dbDir + "/" + dbFileName;
    QFile file(fileName);
    file.open(QFile::ReadOnly);
    QDataStream in(&file);
    in.setVersion(QDataStream::Qt_4_8);

    in >> list;
    file.close();

    if (list.size() == 0) {
        // ���� ������ �����,�� ��������� ������� ������
        OrgStructBranch *b = new OrgStructBranch(1, OrgStructBranch::newHead);
        list.append(*b);
    }
}





