#include "smartScoreWindow.h"
#include "centralWorkSpace.h"
//#include "orgStruct.h"

#include <QtGui>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    qDebug() << "MainWindow::MainWindow START";

    setWindowTitle(tr("SmartScore 0.1"));
    createActions();
    createMenu();
    createToolbars();

    centralWorkSpace = new CentralWorkSpace(Qt::Horizontal);
    setCentralWidget(centralWorkSpace);

    statusBar()->showMessage("");

    qDebug() << "MainWindow::MainWindow END";
}

MainWindow::~MainWindow()
{
}

void MainWindow::createMenu()
{
    fileMenu = menuBar()->addMenu(tr("&����"));
    fileMenu->addAction(exitAction);

    menuBar()->addSeparator();
}

void MainWindow::createActions()
{
    exitAction = new QAction(tr("��&���"), this);
    exitAction->setShortcut(QKeySequence::Close);
    exitAction->setStatusTip(tr("������� ����������"));
    connect(exitAction, SIGNAL(triggered()), this, SLOT(close()));
}

void MainWindow::createToolbars()
{
    qDebug() << "MainWindow::createToolbars START";

    functionList = new QComboBox();
    functionList->addItem(tr("������������"));


    QHBoxLayout *l = new QHBoxLayout;

    l->addWidget(functionList);
    l->addStretch();

    QWidget *w = new QWidget;
    w->setLayout(l);

    toolbar = new QToolBar(this);
    toolbar->addWidget(w);
    toolbar->addAction(exitAction);

    addToolBar(toolbar);

    qDebug() << "MainWindow::createToolbars END";
}
