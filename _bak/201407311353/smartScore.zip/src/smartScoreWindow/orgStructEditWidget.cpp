#include "orgStructEditWidget.h"
#include <QtGui>
#include "orgStruct.h"
#include "../common/lineEdit.h"

OrgStructEditWidget::OrgStructEditWidget(QWidget *parent) :
    QWidget(parent)
{
    // ���� ��� ������������ ��������� � ������������� �����
    char *slotSetChanged = SLOT(setChanged(const QString &));


    nameFullEdit  =
            new LineEditLayout(tr("&������ ������������ �����������"), true);

//    connect(nameFullEdit, SIGNAL(textChanged(const QString &)),
//            this, SLOT(setChanged(const QString &)));
    nameFullEdit->connectTextChanged(this, slotSetChanged);


    nameShortEdit =
            new LineEditLayout(tr("&������� ������������ �����������"), true);

    nameShortEdit->connectTextChanged(this, slotSetChanged);

    noteLabel = new QLabel(tr("&����������"));
    noteEdit = new QTextEdit;
    noteLabel->setBuddy(noteEdit);


    QVBoxLayout *vLayout = new QVBoxLayout;
    vLayout->addLayout(nameFullEdit->layout());
    vLayout->addLayout(nameShortEdit->layout());


    {
        // ������������ ����� �����
        // ������������ ������ �����
        QSize mw = nameShortEdit->labelSizeHint();
        nameFullEdit->setLabelWidth(mw);
    }



    dialogButton =
            new QDialogButtonBox(QDialogButtonBox::Cancel
                                 | QDialogButtonBox::Ok);
    dialogButton->button(QDialogButtonBox::Ok)->setText(tr("���������"));
    dialogButton->button(QDialogButtonBox::Cancel)->setText(tr("��������"));

    connect(dialogButton, SIGNAL(accepted()), this, SLOT(save()));
    connect(dialogButton, SIGNAL(rejected()), this, SLOT(cancel()));

//    dialogButton->button(QDialogButtonBox::Ok)->setVisible(false);
//    dialogButton->button(QDialogButtonBox::Cancel)->setVisible(false);

    vLayout->addWidget(dialogButton);

    vLayout->addStretch();

    setLayout(vLayout);

    modified = false;

    endEdit(); // �������� � ������ �� ��������������
}

void OrgStructEditWidget::editBranch(const OrgStructBranch &branch)
{
    oldBranch = newBranch = branch;
//    newBranch = branch;

    setEditabled(true);

//    qDebug() << tr("����� � ��������������") << QString::number(branch.id) << "*";
    qDebug() << "OrgStructEditWidget::editBranch  " << "branch.flagFresh()=" << branch.flagFresh()
                << "  oldBrunch.flagFresh()=" << oldBranch.flagFresh();

//    if (branch.nameFull.isEmpty()) {
    if (branch._flag != OrgStructBranch::old) {
        editMode = SS::newM;
        nameFullEdit->setText(tr(""));
        nameShortEdit->setText(tr(""));
    } else {
        editMode = SS::editM;
        fillFields(branch);
    }

    dialogButton->button(QDialogButtonBox::Ok)->setVisible(true);
    dialogButton->button(QDialogButtonBox::Ok)->setEnabled(false);
    dialogButton->button(QDialogButtonBox::Cancel)->setVisible(true);

    nameFullEdit->setFocus();



}

void OrgStructEditWidget::viewBranch(const OrgStructBranch &branch)
{
//    qDebug() << "OrgStructEditWidget::viewBranch ";
    editMode = SS::viewM;
    fillFields(branch);

//    qDebug() << "OrgStructEditWidget::viewBranch " << "editMode=" << editMode;

}

void OrgStructEditWidget::save()
{
//    OrgStructBranch b(oldBrunch.id, oldBrunch.parentId,
//                      nameFullEdit->text(), nameShortEdit->text()/*,
//                      noteEdit->*/);
    newBranch.setNameFull(nameFullEdit->text());
    newBranch.setNameShort(nameShortEdit->text());


    emit acceptEdit(newBranch, editMode);
    endEdit();
}

void OrgStructEditWidget::cancel()
{
    qDebug() << oldBranch.nameFull;
    nameFullEdit->setText(oldBranch.nameFull);

    nameShortEdit->setText(oldBranch.nameShort);

    noteEdit->setText(oldBranch._note);


    endEdit();

}


void OrgStructEditWidget::setChanged(const QString &str)
{
//    qDebug() << "OrgStructEditWidget::setChanged :: " << str;
//    qDebug() << "OrgStructEditWidget::setChanged :: editMode=" << editMode;

    if (editMode == SS::viewM)
        return;
//    qDebug() << "OrgStructEditWidget::setChanged :: " << tr("�� �����");

    modified = true;

    dialogButton->button(QDialogButtonBox::Ok)
            ->setEnabled(requirementItemValidate());

    setModal(true);

}

void OrgStructEditWidget::setEditabled(bool regim)
{
    /*nameFullEdit->setEnabled(regim);
    nameShortEdit->setEnabled(regim);
    noteEdit->setEnabled(regim);*/

    bool r = !regim;

    nameFullEdit->setReadOnly(r);
    nameShortEdit->setReadOnly(r);
    noteEdit->setReadOnly(r);
}

void OrgStructEditWidget::endEdit()
{
    dialogButton->button(QDialogButtonBox::Ok)->setVisible(false);
    dialogButton->button(QDialogButtonBox::Cancel)->setVisible(false);

    setEditabled(false);
    setModal(false);
}

bool OrgStructEditWidget::requirementItemValidate() {
    return nameFullEdit->hasAcceptableInput() &&
            nameShortEdit->hasAcceptableInput();
}

void OrgStructEditWidget::fillFields(const OrgStructBranch &branch)
{
    nameFullEdit->setText(branch.nameFull);
    nameFullEdit->home(false);
    nameShortEdit->setText(branch.nameShort);
    nameShortEdit->home(false);
}



