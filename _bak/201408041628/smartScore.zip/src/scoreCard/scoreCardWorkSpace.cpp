#include "scoreCardWorkSpace.h"
#include <QtGui>

ScoreCardWorkSpace::ScoreCardWorkSpace(QWidget *parent) :
    QWidget(parent)
{
    splitter = new QSplitter(this);
    splitter->addWidget(new QPushButton("1111", this));
    splitter->addWidget(new QPushButton("2222", this));

    QVBoxLayout *l = new QVBoxLayout(this);
    l->addWidget(splitter);
    this->setLayout(l);

}
