#ifndef SCORECARDWORKSPACE_H
#define SCORECARDWORKSPACE_H

#include <QWidget>

class QSplitter;

class ScoreCardWorkSpace : public QWidget
{
    Q_OBJECT
public:
    explicit ScoreCardWorkSpace(QWidget *parent = 0);
    
signals:
    
public slots:

private:
    QSplitter *splitter;
    
};

#endif // SCORECARDWORKSPACE_H
