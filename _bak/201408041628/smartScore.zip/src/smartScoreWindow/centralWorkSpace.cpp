#include "centralWorkSpace.h"

#include <QtGui>

#include "../orgStruct/orgStructWorkSpace.h"
#include "../scoreCard/scoreCardWorkSpace.h"

CentralWorkSpace::CentralWorkSpace(QWidget *parent)
    : QWidget(parent)
{

    qDebug("CentralWorkSpace::CentralWorkSpace START");

    nullWidget = new QWidget(this);
    currentWidget = nullWidget;
    layout = new QVBoxLayout(this);
    this->setLayout(layout);
    changeWidget(nullWidget);


    orgStructWorkSpace = 0;

//    showOrgStructWorgSpace();


    qDebug("CentralWorkSpace::CentralWorkSpace END");

}

void CentralWorkSpace::showOrgStructWorkSpace()
{
    qDebug() << "CentralWorkSpace::showOrgStructWorgSpace START";

    if (!orgStructWorkSpace) {
        qDebug() << "CentralWorkSpace::showOrgStructWorgSpace 10";

        orgStructWorkSpace = new OrgStructWorkSpace(this);
        qDebug() << "CentralWorkSpace::showOrgStructWorgSpace 20";
    }
    qDebug() << "CentralWorkSpace::showOrgStructWorgSpace 30";

    changeWidget(orgStructWorkSpace);

    qDebug() << "CentralWorkSpace::showOrgStructWorgSpace END";
}

void CentralWorkSpace::showScoreCardWorkSpace()
{
    qDebug() << "CentralWorkSpace::showScoreCardWorkSpace START";

    if (!scoreCardWorkSpace) {
        scoreCardWorkSpace = new ScoreCardWorkSpace(this);
    }
    changeWidget(scoreCardWorkSpace);

    qDebug() << "CentralWorkSpace::showScoreCardWorkSpace END";

}

void CentralWorkSpace::changeWidget(QWidget *widget)
{
//    qDebug() << "CentralWorkSpace::changeWidget START";
//    qDebug() << "CentralWorkSpace::changeWidget *widget=" << widget;
//    qDebug() << "CentralWorkSpace::changeWidget layout->indexOf(widget)="
//             << layout->indexOf(widget);
    if (layout->indexOf(widget) == -1) {
//        qDebug() << "CentralWorkSpace::changeWidget 10";

        layout->addWidget(widget);
//        qDebug() << "CentralWorkSpace::changeWidget 20";
    }
//    qDebug() << "CentralWorkSpace::changeWidget 20.5";
    currentWidget->setVisible(false);
//    qDebug() << "CentralWorkSpace::changeWidget 30";
    currentWidget = widget;
    currentWidget->show();
//    qDebug() << "CentralWorkSpace::changeWidget END";
}

