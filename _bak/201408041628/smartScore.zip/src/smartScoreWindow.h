#ifndef SMARTSCOREWINDOW_H
#define SMARTSCOREWINDOW_H

#include <QMainWindow>

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();
};

#endif // SMARTSCOREWINDOW_H
