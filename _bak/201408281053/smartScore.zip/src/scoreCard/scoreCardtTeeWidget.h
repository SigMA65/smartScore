﻿#ifndef SCORECARDTTEEWIDGET_H
#define SCORECARDTTEEWIDGET_H

#include "../common/comm.h"
#include "scoreCard.h"

#include <QWidget>
#include <QMap>

class QTreeWidget;
class QLabel;
class QTreeWidgetItem;
class QHBoxLayout;
class QVBoxLayout;
class ScoreCardElement;

/**
 * @brief Дерево формирования ScoreCard
 */
class ScoreCardTreeWidget : public QWidget
{
    Q_OBJECT

    quint32 branchId; ///< Идентификатора текущего подразделения

    QVBoxLayout *treeLayout;
    QTreeWidget *scoreCardTree; ///< Непосредственно Дерево ScoreCard
    QTreeWidgetItem *root; ///< Корень древа целей

    QLabel *headerLabel; ///< Метка с наименованием организации

    QMap<quint32, QTreeWidgetItem *> linkMap; /**< Карта соответствия
                                 между идентификатором и QTreeWidgetItem */

public:
    explicit ScoreCardTreeWidget(QWidget *parent = 0);
    
signals:
    /**
     * @brief Показать или скрыть виджет с оргструктурой
     * Работает как переключатель между виджетами orgStructWidget и
     * scoreCardTreeWidget
     * @param show
     */
    void showOrgStruct(bool show);

    /**
     * @brief viewElement Сигнал "Послать данные о элементе"
     * @note Используется для просмотре, создания или редактирования
     *       элемента
     * @param element Элемент
     * @param mode Режим
     */
    void viewElementOld(const ScoreCardElement &element, SS::EditMode mode);
    void viewElement(const void *object, SS::EditMode mode);

public slots:
    /**
     * @brief Сделать текущей выбранное подразделение
     * @param id - идентификатор подразделения
     * @param name - краткое наименование
     */
    void setBranch(quint32 id, const QString &name);

private slots:
    /**
     * @brief Клинута кнопка с наименованием организации
     */
    void headerlabelClick(QString);

    /**
     * @brief currentItemChanged Сигнал изменение текущего элемента
     * @param curr
     * @param prev
     */
    void currentItemChanged(QTreeWidgetItem *curr, QTreeWidgetItem *prev);

private:
    /**
     * @brief createHeader создать шапку
     * @return
     */
    QHBoxLayout * createHeader();

    /**
     * @brief createConnects создание связей
     */
    void createConnects();

    /**
     * @brief createRootTree создать корень дерева
     */
//    void createRootTree();

    /**
     * @brief initTree инициализовать дерево
     */
    void initTree();

    /**
     * @brief createTree построить дерево
     */
    void createTree();

    /**
     * @brief clearTree очистить дерево
     */
    void clearTree();

    /**
     * @brief createItem создать элемент в дереве
     * @note Вызывается из ф-ций addItem
     *
     * @brief addItem добавить элемент в дерево
     * @param data добавляемый элемент
     */
    QTreeWidgetItem * createItem(const ScoreCardElement &data);
    void addItem(const Perspective &data);
    void addItem(const Objective &data);
    void addItem(const Measure &data);

    /**
     * @brief parentItem Найти родительский элемент в дереве
     * @param id
     * @param parentId
     * @return Ссылка на элемент в дереве
     */
    QTreeWidgetItem * parentItem(quint32 parentId);

    /**
     * @brief Извлечь рабочий элемент из item
     * @param item
     * @return
     */
    ScoreCardElement getElementFromItem(const QTreeWidgetItem &item);

    /**
     * @brief editClick Выполнено действие редактировать подразделение
     */
    void editClick();

    /**
     * @brief newClick Выполнено действие добавить подразделение
     */
    void newClick();

    /**
     * @brief delClick Удаление подразделения
     */
    void delClick();

    void testFillTree();

};

#endif // SCORECARDTTEEWIDGET_H
