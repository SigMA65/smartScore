﻿#ifndef SCORECARDTTEEWIDGET_H
#define SCORECARDTTEEWIDGET_H

#include <QWidget>
#include <QMap>

class QTreeWidget;
class QLabel;
class QTreeWidgetItem;
class QHBoxLayout;
class QVBoxLayout;
class ScoreCardElement;

/**
 * @brief Дерево формирования ScoreCard
 */
class ScoreCardTreeWidget : public QWidget
{
    Q_OBJECT

    quint32 branchId; ///< Идентификатора текущего подразделения

    QVBoxLayout *treeLayout;
    QTreeWidget *scoreCardTree; ///< Непосредственно Дерево ScoreCard
    QTreeWidgetItem *root; ///< Корень древа целей

    QLabel *headerLabel; ///< Метка с наименованием организации

    QMap<quint32, QTreeWidgetItem *> linkMap; /**< Карта соответствия
                                 между идентификатором и QTreeWidgetItem */

public:
    explicit ScoreCardTreeWidget(QWidget *parent = 0);
    
signals:
    /**
     * @brief Показать или скрыть виджет с оргструктурой
     * Работает как переключатель между виджетами orgStructWidget и
     * scoreCardTreeWidget
     * @param show
     */
    void showOrgStruct(bool show);

public slots:
    /**
     * @brief Сделать текущей выбранное подразделение
     * @param id - идентификатор подразделения
     * @param name - краткое наименование
     */
    void setBranch(quint32 id, const QString &name);

private slots:
    /**
     * @brief Клинута кнопка с наименованием организации
     */
    void headerlabelClick(QString);

private:
    /**
     * @brief createHeader создать шапку
     * @return
     */
    QHBoxLayout * createHeader();

    /**
     * @brief createRootTree создать корень дерева
     */
//    void createRootTree();

    /**
     * @brief initTree инициализовать дерево
     */
    void initTree();

    /**
     * @brief createTree построить дерево
     */
    void createTree();

    /**
     * @brief clearTree очистить дерево
     */
    void clearTree();

    /**
     * @brief addItem добавить элемент в дерево
     * @param data добавляемый элемент
     */
    void addItem(const ScoreCardElement &data);

    /**
     * @brief parentItem Найти родительский элемент в дереве
     * @param id
     * @param parentId
     * @return Ссылка на элемент в дереве
     */
    QTreeWidgetItem * parentItem(quint32 parentId);



    void testFillTree();

};

#endif // SCORECARDTTEEWIDGET_H
