#include "scoreCard.h"
#include <QtGui>

ScoreCardElement::ScoreCardElement()
    : type_(ScoreCardElementType(0)), branchId_(0), id_(0),
      parentId_(0), icon_(), name_(""),
      note_("")
{
}

ScoreCardElement::ScoreCardElement(quint32 branchId, quint32 id,
                                   quint32 parentId,
                                   const QString &name,
                                   const QString &note)
    : branchId_(branchId), id_(id), parentId_(parentId), name_(name),
      note_(note)
{
//    branchId_ = branchId;
//    id_ = id;
//    parentId_ = parentId;
//    name_ = name;
    //    note_ = note;
}

ScoreCardElement::ScoreCardElement(const ScoreCardElement &other)
    : type_(other.type_), branchId_(other.branchId_), id_(other.id_),
      parentId_(other.parentId_), icon_(other.icon_), name_(other.name_),
      note_(other.note_)
{
}

//QIcon ScoreCardElement::icon() const
//{
//    QIcon * const d = icon_;
//      qDebug() << "ScoreCardElement::icon icon(d)=" << d;
//                            return *d;}

Perspective::Perspective(quint32 branchId, quint32 id, quint32 parentId,
                         const QString &name, const QString &note) :
    ScoreCardElement(branchId, id, parentId, name, note)
{
    type_ = ScoreCardElement::perspective;
    icon_ = new QIcon(":/img/find.png");
    qDebug() << "Perspective::Perspective icon=" << icon_;
}

Objective::Objective(quint32 branchId, quint32 id, quint32 parentId,
                         const QString &name, const QString &note) :
    ScoreCardElement(branchId, id, parentId, name, note)
{
    type_ = ScoreCardElement::objective;
    icon_ = new QIcon(":/img/target.png");
}

Measure::Measure(quint32 branchId, quint32 id, quint32 parentId,
                         const QString &name, const QString &note) :
    ScoreCardElement(branchId, id, parentId, name, note)
{
    type_ = ScoreCardElement::measure;
    icon_ = new QIcon(":/img/star1_32.png");
}






