#include "scoreCardEditWidget.h"
#include "../common/editForm.h" //TODO:* !!!!!!!!!!!!!! cpp!!!
//#include "../common/editRow.h"
#include"scoreCard.h"

#include <QtGui>

typedef ScoreCardPerspectiveEditWidget P;

P::ScoreCardPerspectiveEditWidget(
        QWidget *parent) :
    EditForm<ScoreCardElement>(parent)
{
    qDebug() << tr("ScoreCardPerspectiveEditWidget::ScoreCardPerspectiveEditWidget START");
    name = new QLineEdit(this);
    connectSignalAndValidator(name,
                              SS::st_TextChanged|SS::st_MandatoryValidator);

    note = new QTextEdit(this);
    connectSignalAndValidator(note, SS::st_TextChanged);

    QFormLayout *l = new QFormLayout;
    l->addRow(SS::createMandatoryLabel(tr("&Название")), name);
    l->addRow(tr("&Примечание"), note);

    addEditLayout(l, name);

    setTitleIcon(QPixmap(":/img/find.png"));
    setTitleText(tr("Перспектива"));

    endEdit();

    qDebug() << tr("ScoreCardPerspectiveEditWidget::ScoreCardPerspectiveEditWidget END");
}

void P::revertOldValues(const ScoreCardElement *oldObj)
{
}

void P::setReadOnly(bool ro)
{
    qDebug() << tr("ScoreCardEditWidget::setReadOnly START");
}

bool P::requirementItemValidate()
{
}

void P::fillFields(const ScoreCardElement *object)
{
}

void P::clearFields()
{
}

void P::setNewValues(ScoreCardElement *newObj)
{
}
