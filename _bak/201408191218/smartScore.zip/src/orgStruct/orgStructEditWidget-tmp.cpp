#include "orgStructEditWidget-tmp.h"
#include <QtGui>
#include "orgStruct.h"
#include "../common/lineEdit.h"





