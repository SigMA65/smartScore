#include "scoreCardDb.h"
#include "scoreCard.h"
#include "../common/common.h"

#include <QString>
#include <QDebug>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlRecord>
#include <QErrorMessage>

scoreCardDb::scoreCardDb()
{
//    qDebug() << QObject::tr("OrgStructDb::OrgStructDb START");
    db = QSqlDatabase::addDatabase("QSQLITE");
    QString dbPath = dbDir + "/" + dbName;
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        QErrorMessage msg;
        msg.setWindowTitle(QObject::tr("База данных"));
        msg.showMessage(QObject::tr("Ошибка открытия базы данных %1").arg(dbPath));
    }
}

scoreCardDb::~scoreCardDb()
{
}
