﻿#ifndef COMMON_H
#define COMMON_H

class QString;

const QString dbDir = "db"; ///< Директория файлов тестовой (для прототипа) БД
const QString dbName = "smartScore.bd"; ///< Имя БД SQLite

//TODO:***
//enum EditMode {editM, newM}; ///< Режимы редактирования


#endif // COMMON_H
