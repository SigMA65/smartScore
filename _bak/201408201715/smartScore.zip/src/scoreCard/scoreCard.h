﻿#ifndef SCORECARD_H
#define SCORECARD_H

//#include <QtGlobal>
#include <QList>
#include <QString>

#include "../common/editRow.h"

class QIcon;
class ScoreCardElement;
class Prototipe;
//class QString;

/**
 * @brief ScoreCard структура
 */
class ScoreCard
{
public:

private:
    QList<ScoreCardElement> scoreCardList; ///< Список системы показателей
};

/**
 * @brief Базовый класс для элементов (перспектива, цель, показатель) ScoreCard
 */
class ScoreCardElement : public EditRow
{
    friend class Perspective;
public:
    enum ScoreCardElementType{perspective, ///< перспектива
                              objective, ///< цель
                              measure ///< показатель
                             };

    ScoreCardElement(quint32 id,
                quint32 parentId,
                const QString &name,
                const QString &note = 0);
private:

    ScoreCardElementType type_; ///< Тип элемента
    quint32 id_; ///< Идентификатор элемента
    quint32 parentId_; ///< Идентификатор родительского элемента
    QIcon *icon_; ///< Иконка, соответсвующая элементу
    QString name_; ///< Наименование
    QString note_; ///< Примечание
};

/**
 * @brief Перспектива
 */
class Perspective : public ScoreCardElement
{
    Perspective(quint32 id,
                quint32 parentId,
                const QString &name,
                const QString &note = 0);

};

#endif // SCORECARD_H
