﻿#ifndef SCORECARDWORKSPACE_H
#define SCORECARDWORKSPACE_H

#include <QWidget>

class QSplitter;
class OrgStructWidget;
class ScoreCardTreeWidget;
class ScoreCardPerspectiveEditWidget;

class ScoreCardWorkSpace : public QWidget
{
    Q_OBJECT

    QWidget *nullWidget;
    QSplitter *splitter;
    OrgStructWidget *orgStructWidget;
    ScoreCardTreeWidget *scoreCardTreeWidget;
    ScoreCardPerspectiveEditWidget *scoreCardEditWidget;

public:
    explicit ScoreCardWorkSpace(QWidget *parent = 0);
    ~ScoreCardWorkSpace();

signals:
    
public slots:
    /**
     * @brief Показать дерево scoreCard
     * @param id - идентификатор подразделения
     * @param name - краткое наименование
     */
    void showScoreCard(quint32 id, const QString &name);

    /**
     * @brief Показать или скрыть виджет с оргструктурой
     * Работает как переключатель между виджетами orgStructWidget и
     * scoreCardTreeWidget
     * @param show
     */
    void showOrgStruct(bool show);

private:
    
};

#endif // SCORECARDWORKSPACE_H
