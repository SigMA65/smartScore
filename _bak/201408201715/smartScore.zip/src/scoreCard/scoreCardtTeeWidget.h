﻿#ifndef SCORECARDTTEEWIDGET_H
#define SCORECARDTTEEWIDGET_H

#include <QWidget>

class QTreeWidget;
class QLabel;

/**
 * @brief Дерево формирования ScoreCard
 */
class ScoreCardTreeWidget : public QWidget
{
    Q_OBJECT
public:
    explicit ScoreCardTreeWidget(QWidget *parent = 0);
    
signals:
    /**
     * @brief Показать или скрыть виджет с оргструктурой
     * Работает как переключатель между виджетами orgStructWidget и
     * scoreCardTreeWidget
     * @param show
     */
    void showOrgStruct(bool show);

public slots:
    /**
     * @brief Сделать текущей выбранное подразделение
     * @param id - идентификатор подразделения
     * @param name - краткое наименование
     */
    void setBranch(quint32 id, const QString &name);

private slots:
    /**
     * @brief Клинута кнопка с наименованием организации
     */
    void headerlabelClick(QString);

private:

    QTreeWidget *scoreCardTree; ///< Непосредственно Дерево ScoreCard
    quint32 branchId; ///< Идентификатора текущего подразделения
    QLabel *headerLabel; ///< Метка с наименованием организации
    
};

#endif // SCORECARDTTEEWIDGET_H
