#include "scoreCardWorkSpace.h"

#include <QtGui>
#include "../orgStruct/orgStructWidget.h"
#include "scoreCardtTeeWidget.h"
#include "scoreCardEditWidget.h"

ScoreCardWorkSpace::ScoreCardWorkSpace(QWidget *parent) :
    QWidget(parent)
{
    qDebug() << "ScoreCardWorkSpace::ScoreCardWorkSpace START";

    splitter = 0;
    nullWidget = new QWidget(this);
    orgStructWidget = 0;
    scoreCardTreeWidget = 0;
    scoreCardEditWidget = 0;

    orgStructWidget = new OrgStructWidget(this);
    orgStructWidget->createContextMenu4Choose();

    scoreCardTreeWidget = new ScoreCardTreeWidget(this);
    scoreCardTreeWidget->setVisible(false);

    qDebug() << "ScoreCardWorkSpace::ScoreCardWorkSpace 10";
    scoreCardEditWidget = new ScoreCardPerspectiveEditWidget(this);
    qDebug() << "ScoreCardWorkSpace::ScoreCardWorkSpace 10.1";
    scoreCardEditWidget->setVisible(false);

    QWidget *leftPanelWidget = new QWidget;
    QVBoxLayout *leftPanelLayout = new QVBoxLayout;
    leftPanelLayout->setMargin(0);
    leftPanelLayout->addWidget(orgStructWidget);
    leftPanelLayout->addWidget(scoreCardTreeWidget);
    leftPanelWidget->setLayout(leftPanelLayout);

    QWidget *rightPanelWidget = new QWidget;
    QVBoxLayout *rightPaneLayout = new QVBoxLayout;
    rightPaneLayout->setMargin(0);
    rightPaneLayout->addWidget(nullWidget);
    rightPaneLayout->addWidget(scoreCardEditWidget);
    rightPanelWidget->setLayout(rightPaneLayout);

    splitter = new QSplitter();
    splitter->addWidget(leftPanelWidget);
    splitter->addWidget(rightPanelWidget);
//    splitter->addWidget(new QPushButton("1111", this));
//    splitter->addWidget(new QPushButton("2222", this));
    splitter->setStretchFactor(1,1);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(splitter);
    this->setLayout(mainLayout);

    connect(orgStructWidget, SIGNAL(chooseBranch(quint32,QString)),
            this, SLOT(showScoreCard(quint32,QString)));
    connect(orgStructWidget, SIGNAL(chooseBranch(quint32,QString)),
            scoreCardTreeWidget, SLOT(setBranch(quint32,QString)));
    connect(scoreCardTreeWidget, SIGNAL(showOrgStruct(bool)),
            this, SLOT(showOrgStruct(bool)));

    qDebug() << "ScoreCardWorkSpace::ScoreCardWorkSpace END";
}

ScoreCardWorkSpace::~ScoreCardWorkSpace()
{
    qDebug() << "ScoreCardWorkSpace::~ScoreCardWorkSpace() START";
//    qDebug() << "ScoreCardWorkSpace::~ScoreCardWorkSpace() orgStructWidget="
//             << orgStructWidget;

//    delete splitter;
    qDebug() << "ScoreCardWorkSpace::~ScoreCardWorkSpace() END";
}

void ScoreCardWorkSpace::showOrgStruct(bool show)
{
    orgStructWidget->setVisible(show);
    scoreCardTreeWidget->setVisible(!show);
    scoreCardEditWidget->setVisible(!show);
}

void ScoreCardWorkSpace::showScoreCard(quint32 id, const QString &name)
{
//    qDebug() << tr("ScoreCardWorkSpace::setBranch id=%1 name=%2")
//                .arg(id).arg(name);
    showOrgStruct(false);
}
