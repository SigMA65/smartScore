#include "scoreCard.h"
#include <QtGui>

ScoreCardElement::ScoreCardElement(quint32 id,
                                   quint32 parentId,
                                   const QString &name,
                                   const QString &note)
    : EditRow()
{
    id_ = id;
    parentId_ = parentId;
    name_ = name;
    note_ = note;
}


Perspective::Perspective(quint32 id, quint32 parentId, const QString &name, const QString &note) :
    ScoreCardElement(id, parentId, name, note)
{
    type_ = ScoreCardElement::perspective;
    icon_ = new QIcon("../img/find.png");
}






