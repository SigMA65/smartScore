#include "scoreCardEditWidget.h"
#include "../common/editForm.h" //TODO:* !!!!!!!!!!!!!! cpp!!!
//#include "../common/editRow.h"
#include"scoreCard.h"

#include <QtGui>

typedef ScoreCardPerspectiveEditWidget P;

P::ScoreCardPerspectiveEditWidget(
        QWidget *parent) :
    EditForm<ScoreCardElement>(parent)
{
    qDebug() << tr("ScoreCardEditWidget::ScoreCardEditWidget START");
    name = new QLineEdit(this);
    connectSignalAndValidator(name,
                              SS::st_TextChanged|SS::st_MandatoryValidator);

    note = new QTextEdit(this);
    connectSignalAndValidator(note, SS::st_TextChanged);

    QFormLayout *l = new QFormLayout;
    l->addRow(SS::createMandatoryLabel(tr("&Название")), name);
    l->addRow(tr("&Примечание"), note);

    addEditLayout(l, name);

    endEdit();

    qDebug() << tr("ScoreCardEditWidget::ScoreCardEditWidget END");
}

void P::revertOldValues(const ScoreCardElement *oldObj)
{
}

void P::setReadOnly(bool ro)
{
    qDebug() << tr("ScoreCardEditWidget::setReadOnly START");
}

bool P::requirementItemValidate()
{
}

void P::fillFields(const ScoreCardElement *object)
{
}

void P::clearFields()
{
}

void P::setNewValues(ScoreCardElement *newObj)
{
}
