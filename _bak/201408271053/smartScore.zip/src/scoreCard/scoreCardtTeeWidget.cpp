#include "scoreCardtTeeWidget.h"
#include "scoreCard.h"

#include <QtGui>

ScoreCardTreeWidget::ScoreCardTreeWidget(QWidget *parent) :
    QWidget(parent)
{
    qDebug() << "ScoreCardTreeWidget::ScoreCardTreeWidget START";

    treeLayout = new QVBoxLayout;
    scoreCardTree = 0;
    root = 0;

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->setMargin(0);

    QHBoxLayout *headerLabelLayout = createHeader();

    initTree();

//    scoreCardTree = new QTreeWidget(this);

//    qDebug() << "ScoreCardTreeWidget::ScoreCardTreeWidget scoreCardTree=" << scoreCardTree;
//    QTreeWidgetItem *r = scoreCardTree->topLevelItem(0);
//    qDebug() << "ScoreCardTreeWidget::ScoreCardTreeWidget scoreCardTree=" << r->text(0);


    mainLayout->addLayout(headerLabelLayout);
//    mainLayout->addWidget(scoreCardTree);
    mainLayout->addLayout(treeLayout);
//    mainLayout->addStretch();

//    mainLayout->addWidget(new QPushButton(tr("Заполнить(тест)")));

    this->setLayout(mainLayout);

    createConnects();

    qDebug() << "ScoreCardTreeWidget::ScoreCardTreeWidget END";
}

void ScoreCardTreeWidget::setBranch(quint32 id, const QString &name)
{
    qDebug() << tr("ScoreCardTreeWidget::setBranch id=%1 name=%2")
                .arg(id).arg(name);

    branchId = id;

//    if (scoreCardTree) {
//        delete scoreCardTree;
//    }

    scoreCardTree = new QTreeWidget(this);
    QString text = QString("<a href=\"null\">%1</a>").arg(name);

//    headerLabel->setTextFormat(Qt::RichText);
    //    QString text =
//            QString("<a href=\"null\">%1</a> <img src=\"redo24_h.gif\"> ").arg(name);

//    qDebug() << tr("ScoreCardTreeWidget::setBranch text=%1").arg(text);

    headerLabel->setText(text);
    headerLabel->setMinimumWidth(headerLabel->sizeHint().width());
    headerLabel->setMinimumHeight(20);

//    clearTree();
    createTree();
}

void ScoreCardTreeWidget::headerlabelClick(QString)
{
    emit showOrgStruct(true);
}

void ScoreCardTreeWidget::currentItemChanged(QTreeWidgetItem *curr, QTreeWidgetItem *prev)
{
    (void)prev;

//    qDebug() << "ScoreCardTreeWidget::currentItemChanged type=" << curr->type();
    if (curr->type() == -1)
        return; // Корневой элемент не обслуживаем

    ScoreCardElement e = getElementFromItem(*curr);
    qDebug() << "ScoreCardTreeWidget::currentItemChanged " << e.name();
//    emit viewElement(e, SS::viewM);

    Perspective p = curr->data(0, Qt::UserRole).value<Perspective>();
    qDebug() << "ScoreCardTreeWidget::currentItemChanged name=" << p.name();
    void *v = static_cast<void *>(&p);
    qDebug() << "ScoreCardTreeWidget::currentItemChanged name=" << ((Perspective*)v)->name();
    emit viewElement(v);
}

QHBoxLayout * ScoreCardTreeWidget::createHeader()
{
    headerLabel = new QLabel(this);
    headerLabel->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    headerLabel->setAlignment(Qt::AlignCenter);
    connect(headerLabel, SIGNAL(linkActivated(QString)),
            this, SLOT(headerlabelClick(QString)));
    QLabel *redoIcon = new QLabel(this);
//    QPixmap pix(":/img/redo24_h.png");
    redoIcon->setPixmap(QPixmap(":/img/redo24_h.png"));
    redoIcon->setMaximumSize(redoIcon->sizeHint());
//    redoIcon->setPixmap(pix.scaled(pix.size()));
//    redoIcon->setFrameStyle(QFrame::Panel | QFrame::Raised);
    QHBoxLayout *headerLabelLayout = new QHBoxLayout;
    headerLabelLayout->addWidget(redoIcon);
    headerLabelLayout->addWidget(headerLabel);
    headerLabelLayout->setMargin(0);
    headerLabelLayout->setSpacing(0);

    return headerLabelLayout;
}

void ScoreCardTreeWidget::createConnects()
{
    connect(scoreCardTree,
            SIGNAL(currentItemChanged(QTreeWidgetItem*,QTreeWidgetItem*)),
            this, SLOT(currentItemChanged(QTreeWidgetItem*,QTreeWidgetItem*)));
}

//void ScoreCardTreeWidget::createRootTree()
//{
//}

void ScoreCardTreeWidget::initTree()
{
    if (!scoreCardTree) {
        scoreCardTree = new QTreeWidget();
        scoreCardTree->setHeaderHidden(true);
    }
    // Type=-1 - обозначает корневой элемент
    root = new QTreeWidgetItem(scoreCardTree, -1);
    root->setText(0, tr("Древо целей"));
//    scoreCardTree->addTopLevelItem(root);
    treeLayout->addWidget(scoreCardTree);

    scoreCardTree->setSizePolicy(QSizePolicy::Ignored,
                                 QSizePolicy::Expanding);
}


void ScoreCardTreeWidget::createTree()
{
    clearTree();
    //!!!!!!!!!!!!!!!!!!!!!
    testFillTree();
}

void ScoreCardTreeWidget::clearTree()
{
//    qDebug() << "ScoreCardTreeWidget::clearTree childCount()=" << root->childCount();

    QList<QTreeWidgetItem *> list = root->takeChildren();
    foreach (QTreeWidgetItem *item, list)
        delete item;

    /*for (int i = 0; i < root->childCount(); ++i) {
        QTreeWidgetItem *item = root->takeChild(i);
        qDebug() << tr("ScoreCardTreeWidget::clearTree i=%1 text=%2")
                    .arg(i).arg(item->text(0));
        delete item;
    }*/
}

QTreeWidgetItem *  ScoreCardTreeWidget::createItem(const ScoreCardElement &data)
{
//    qDebug() << tr("ScoreCardTreeWidget::createItem START");
    QTreeWidgetItem *parent = parentItem(data.parentId());
    QTreeWidgetItem *item = new QTreeWidgetItem(parent, data.type());

    item->setText(0, data.name());
    item->setIcon(0, data.icon());

    linkMap.insert(data.id(), item);

//    qDebug() << tr("ScoreCardTreeWidget::createItem STOP");
    return item;
}

//TODO:*
// Переделать, чтобы не было дублирования с предыдущей
void ScoreCardTreeWidget::addItem(const Perspective &data)
{
//    qDebug() << tr("ScoreCardTreeWidget::addItem Perspective");
    createItem(data)->setData(0, Qt::UserRole, QVariant::fromValue(data));
//    item->setData(0, Qt::UserRole, QVariant::fromValue(data));
}

void ScoreCardTreeWidget::addItem(const Objective &data)
{
//    qDebug() << tr("ScoreCardTreeWidget::addItem Objective");
    createItem(data)->setData(0, Qt::UserRole, QVariant::fromValue(data));
//    item->setData(0, Qt::UserRole, QVariant::fromValue(data));
}

void ScoreCardTreeWidget::addItem(const Measure &data)
{
//    qDebug() << tr("ScoreCardTreeWidget::addItem Objective");
    createItem(data)->setData(0, Qt::UserRole, QVariant::fromValue(data));
//    item->setData(0, Qt::UserRole, QVariant::fromValue(data));
}

QTreeWidgetItem *ScoreCardTreeWidget::parentItem(/*quint32 id,*/
                                                 quint32 parentId)
{
    QTreeWidgetItem *parent = 0;

    if (linkMap.contains(parentId))
        parent = linkMap.value(parentId);
    else
        parent = root;

    return parent;
}

ScoreCardElement ScoreCardTreeWidget::getElementFromItem(
        const QTreeWidgetItem &item)
{
    ScoreCardElement e =
            item.data(0, Qt::UserRole).value<ScoreCardElement>();
    return e;
}

void ScoreCardTreeWidget::testFillTree()
{
//    static int n = 0;
//    if (0<n++) return;

    Perspective *p1 = new Perspective(branchId, 1, branchId, tr("Финансы"));

//    qDebug() << tr("ScoreCardTreeWidget::testFillTree icon=")
//                << p1->icon();
//    addItem(static_cast<ScoreCardElement>(*p1));
    addItem(*p1);

    Objective *o1 = new Objective(branchId, 2, 1, tr("Много денег"));
//    addItem(static_cast<ScoreCardElement>(*o1));
    addItem(*o1);

    Measure *m1 = new Measure(branchId, 3, 2, tr("Количество"));
//    addItem(static_cast<ScoreCardElement>(*m1));
    addItem(*m1);


    //!!!!!!!!!!!!!!
    QTreeWidgetItem *i1 = new QTreeWidgetItem(root);
    i1->setText(0, tr("11111111"));
    QTreeWidgetItem *i2 = new QTreeWidgetItem(i1);
    i2->setText(0, tr("22222222"));

}


