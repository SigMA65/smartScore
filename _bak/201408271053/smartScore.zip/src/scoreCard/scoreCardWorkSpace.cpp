#include "scoreCardWorkSpace.h"

#include "../orgStruct/orgStructWidget.h"
#include "scoreCardtTeeWidget.h"
#include "scoreCardPerspectiveEditWidget.h"
#include "scoreCard.h"

#include <QtGui>

ScoreCardWorkSpace::ScoreCardWorkSpace(QWidget *parent) :
    QWidget(parent)
{
//    qDebug() << "ScoreCardWorkSpace::ScoreCardWorkSpace START";

    splitter = 0;
    nullWidget = new QWidget(this);
    orgStructWidget = 0;
    scoreCardTreeWidget = 0;
    scoreCardEditWidgets = new QWidget(this);

    //=====================
//    scoreCardEditWidgets->setSizePolicy(QSizePolicy::Expanding,
//                                       QSizePolicy::Expanding);
    //=====================

    scoreCardEditWidgets->setVisible(false);
    scoreCardPerspectiveEditWidget = 0;

    orgStructWidget = new OrgStructWidget(this);
    orgStructWidget->createContextMenu4Choose();

    scoreCardTreeWidget = new ScoreCardTreeWidget(this);
    scoreCardTreeWidget->setVisible(false);

//    qDebug() << "ScoreCardWorkSpace::ScoreCardWorkSpace 10";
    scoreCardPerspectiveEditWidget =
            new ScoreCardPerspectiveEditWidget(scoreCardEditWidgets);

    QVBoxLayout *scoreCardEditLayout = new QVBoxLayout();
    scoreCardEditLayout->addWidget(scoreCardPerspectiveEditWidget);

    scoreCardEditWidgets->setLayout(scoreCardEditLayout);

    scoreCardPerspectiveEditWidget->setVisible(false);
//    qDebug() << "ScoreCardWorkSpace::ScoreCardWorkSpace 10.1";

    QWidget *leftPanelWidget = new QWidget;
    QVBoxLayout *leftPanelLayout = new QVBoxLayout;
    leftPanelLayout->setMargin(0);
    leftPanelLayout->addWidget(orgStructWidget);
    leftPanelLayout->addWidget(scoreCardTreeWidget);
    leftPanelWidget->setLayout(leftPanelLayout);

    QWidget *rightPanelWidget = new QWidget;
    QVBoxLayout *rightPaneLayout = new QVBoxLayout;
    rightPaneLayout->setMargin(0);
    rightPaneLayout->addWidget(nullWidget);
//    rightPaneLayout->addWidget(scoreCardPerspectiveEditWidget);
    rightPaneLayout->addWidget(scoreCardEditWidgets);
    rightPanelWidget->setLayout(rightPaneLayout);

    splitter = new QSplitter();
    splitter->addWidget(leftPanelWidget);
    splitter->addWidget(rightPanelWidget);
//    splitter->addWidget(new QPushButton("1111", this));
//    splitter->addWidget(new QPushButton("2222", this));
    splitter->setStretchFactor(1,1);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(splitter);
    this->setLayout(mainLayout);

    createConnects();

    qDebug() << "ScoreCardWorkSpace::ScoreCardWorkSpace END";
}

ScoreCardWorkSpace::~ScoreCardWorkSpace()
{
//    qDebug() << "ScoreCardWorkSpace::~ScoreCardWorkSpace() START";
//    qDebug() << "ScoreCardWorkSpace::~ScoreCardWorkSpace() orgStructWidget="
//             << orgStructWidget;

//    delete splitter;
//    qDebug() << "ScoreCardWorkSpace::~ScoreCardWorkSpace() END";
}

void ScoreCardWorkSpace::showOrgStruct(bool show)
{
    orgStructWidget->setVisible(show);
    scoreCardTreeWidget->setVisible(!show);
//    scoreCardPerspectiveEditWidget->setVisible(!show);
    scoreCardEditWidgets->setVisible(!show);
}

void ScoreCardWorkSpace::viewElementOld(const ScoreCardElement &element,
                                     SS::EditMode mode)
{
    qDebug() << "ScoreCardWorkSpace::viewElement START";
    typedef ScoreCardElement Element;
    typedef Element::ScoreCardElementType Type;

    Type type = element.type();

    nullWidget->setVisible(false);
    switch (type) {
    case Element::perspective: {
        scoreCardPerspectiveEditWidget->setVisible(true);

        {// VVVV Это для тестирования преобразования
            qDebug() << "ScoreCardWorkSpace::viewElement 10.1";
        ScoreCardElement *el0 = const_cast<ScoreCardElement*>(&element);
        qDebug() << "ScoreCardWorkSpace::viewElement 10.2";
//        ScoreCardElement el = const_cast<ScoreCardElement>(element);
//        Perspective p = static_cast<Perspective>(el0);
        Perspective *p = new Perspective();
        qDebug() << "ScoreCardWorkSpace::viewElement (1)testPerspectiveProperty=" <<
                p->testPerspectiveProperty;
        qDebug() << "ScoreCardWorkSpace::viewElement 10.3";
        p = dynamic_cast<Perspective*>(el0);
        qDebug() << "ScoreCardWorkSpace::viewElement 10.4";
        qDebug() << "ScoreCardWorkSpace::viewElement name=" << p->name();
        qDebug() << "ScoreCardWorkSpace::viewElement 10.6";
//        qDebug() << "ScoreCardWorkSpace::viewElement (2)testPerspectiveProperty=" <<
//                p->testPerspectiveProperty;
        delete p;
        }

        break;
    }
    default:
        nullWidget->setVisible(true);
        scoreCardPerspectiveEditWidget->setVisible(false);
        break;
    }
}

void ScoreCardWorkSpace::viewElement(const void *object)
{
    qDebug() << "ScoreCardWorkSpace::viewElement START";
    typedef ScoreCardElement Element;
    typedef Element::ScoreCardElementType Type;

    Element *element = static_cast<Element *>(
                const_cast<void*>(object));
    Type type = element->type();

    nullWidget->setVisible(false);
    switch (type) {
    case Element::perspective:
    {
        scoreCardPerspectiveEditWidget->setVisible(true);
        Perspective *p = static_cast<Perspective *>(
                    const_cast<void*>(object));
        qDebug() << "ScoreCardWorkSpace::viewTest name=" << p->name();
        qDebug() << "ScoreCardWorkSpace::viewTest testPerspectiveProperty=" << p->testPerspectiveProperty;
        break;
    }
    default:
        nullWidget->setVisible(true);
        scoreCardPerspectiveEditWidget->setVisible(false);
        break;

    }


}


void ScoreCardWorkSpace::showScoreCard(quint32 id, const QString &name)
{
//    qDebug() << tr("ScoreCardWorkSpace::setBranch id=%1 name=%2")
//                .arg(id).arg(name);
    showOrgStruct(false);
}

void ScoreCardWorkSpace::createConnects()
{
    connect(orgStructWidget, SIGNAL(chooseBranch(quint32,QString)),
            this, SLOT(showScoreCard(quint32,QString)));
    connect(orgStructWidget, SIGNAL(chooseBranch(quint32,QString)),
            scoreCardTreeWidget, SLOT(setBranch(quint32,QString)));
    connect(scoreCardTreeWidget, SIGNAL(showOrgStruct(bool)),
            this, SLOT(showOrgStruct(bool)));
//    connect(scoreCardTreeWidget,
//            SIGNAL(viewElement(ScoreCardElement,SS::EditMode)),
//            this, SLOT(viewElement(ScoreCardElement,SS::EditMode)));
    connect(scoreCardTreeWidget,
            SIGNAL(viewElement(const void *)),
            this, SLOT(viewElement(const void*)));
}

