#include "editForm-tmp.h"
#include "editRow.h"
#include "../common/comm.h"

#include <QtGui>


EditForm::EditForm(QWidget *parent)
    : EditFormSig(parent)
{
}




