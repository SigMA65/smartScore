#include "orgStructEditWidget.h"
#include <QtGui>
#include "orgStruct.h"
#include "../common/lineEdit.h"


void OrgStructEditWidget::editBranch(const OrgStructBranch &branch)
{
    oldBranch = newBranch = branch;

    setEditabled(true);

//    qDebug() << tr("����� � ��������������") << QString::number(branch.id) << "*";
//    qDebug() << "OrgStructEditWidget::editBranch  " << "branch.flagFresh()=" << branch.flagFresh()
//                << "  oldBrunch.flagFresh()=" << oldBranch.flagFresh();

    if (branch.flag_ != OrgStructBranch::old) {
        editMode = SS::newM;
//        nameFullEdit->setText(tr(""));
//        nameShortEdit->setText(tr(""));
//        noteEdit->setText(tr(""));
        fillFields();
    } else {
        editMode = SS::editM;
        fillFields(&branch);
    }

    dialogButton->button(QDialogButtonBox::Ok)->setVisible(true);
    dialogButton->button(QDialogButtonBox::Ok)->setEnabled(false);
    dialogButton->button(QDialogButtonBox::Cancel)->setVisible(true);

    nameFullEdit->setFocus();
}

void OrgStructEditWidget::viewBranch(const OrgStructBranch &branch)
{
//    qDebug() << "OrgStructEditWidget::viewBranch ";
    editMode = SS::viewM;
    fillFields(&branch);

//    qDebug() << "OrgStructEditWidget::viewBranch " << "editMode=" << editMode;

}

void OrgStructEditWidget::save()
{
    newBranch.setNameFull(nameFullEdit->text());
    newBranch.setNameShort(nameShortEdit->text());
    newBranch.setNote(noteEdit->toPlainText());

    emit acceptEdit(newBranch, editMode);
    endEdit();
}

void OrgStructEditWidget::cancel()
{
//    qDebug() << oldBranch.nameFull;
    nameFullEdit->setText(oldBranch.nameFull);

    nameShortEdit->setText(oldBranch.nameShort);

    noteEdit->setText(oldBranch.note_);


    endEdit();

}


void OrgStructEditWidget::setChanged(const QString &str)
{

//    qDebug() << "OrgStructEditWidget::setChanged :: " << str;
//    qDebug() << "OrgStructEditWidget::setChanged :: editMode=" << editMode;

    if (editMode == SS::viewM)
        return;
//    qDebug() << "OrgStructEditWidget::setChanged :: " << tr("�� �����");

    modified = true;

    dialogButton->button(QDialogButtonBox::Ok)
            ->setEnabled(requirementItemValidate());

    setModal(true);

}

void OrgStructEditWidget::setEditabled(bool regim)
{
    bool r = !regim;

    nameFullEdit->setReadOnly(r);
    nameShortEdit->setReadOnly(r);
    noteEdit->setReadOnly(r);
}

void OrgStructEditWidget::endEdit()
{
    dialogButton->button(QDialogButtonBox::Ok)->setVisible(false);
    dialogButton->button(QDialogButtonBox::Cancel)->setVisible(false);

    setEditabled(false);
    setModal(false);
}

bool OrgStructEditWidget::requirementItemValidate() {
    return nameFullEdit->hasAcceptableInput() &&
            nameShortEdit->hasAcceptableInput();
}

void OrgStructEditWidget::fillFields(const OrgStructBranch *branch)
{
    if (branch) {
        nameFullEdit->setText(branch->nameFull);
        nameFullEdit->setText(branch->nameFull);
        nameShortEdit->setText(branch->nameShort);
        nameShortEdit->home(false);
        noteEdit->setText(branch->note_);
    } else {
        nameFullEdit->setText(tr(""));
        nameShortEdit->setText(tr(""));
        noteEdit->setText(tr(""));
    }
}



