#include "scoreCardtTeeWidget.h"

#include <QtGui>

ScoreCardTreeWidget::ScoreCardTreeWidget(QWidget *parent) :
    QWidget(parent)
{
    qDebug() << "ScoreCardTreeWidget::ScoreCardTreeWidget START";
    scoreCardTree = new QTreeWidget;

    headerLabel = new QLabel(this);
    headerLabel->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    headerLabel->setAlignment(Qt::AlignCenter);
    connect(headerLabel, SIGNAL(linkActivated(QString)),
            this, SLOT(headerlabelClick(QString)));
    QLabel *redoIcon = new QLabel(this);
    QPixmap pix(":/img/redo24_h.png");
    redoIcon->setPixmap(QPixmap(":/img/redo24_h.png"));
    redoIcon->setMaximumSize(redoIcon->sizeHint());
//    redoIcon->setPixmap(pix.scaled(pix.size()));
//    redoIcon->setFrameStyle(QFrame::Panel | QFrame::Raised);
    QHBoxLayout *headerLabelLayout = new QHBoxLayout;
    headerLabelLayout->addWidget(redoIcon);
    headerLabelLayout->addWidget(headerLabel);
    headerLabelLayout->setMargin(0);
    headerLabelLayout->setSpacing(0);

    QVBoxLayout *mainLayout = new QVBoxLayout;
//    mainLayout->addWidget(headerLabel);
    mainLayout->addLayout(headerLabelLayout);
    mainLayout->addWidget(scoreCardTree);
    mainLayout->addStretch();
    mainLayout->setMargin(0);
    this->setLayout(mainLayout);
}

void ScoreCardTreeWidget::setBranch(quint32 id, const QString &name)
{
    qDebug() << tr("ScoreCardTreeWidget::setBranch id=%1 name=%2")
                .arg(id).arg(name);

    branchId = id;

    if (scoreCardTree) {
        delete scoreCardTree;
    }

    scoreCardTree = new QTreeWidget(this);
    QString text = QString("<a href=\"null\">%1</a>").arg(name);

//    headerLabel->setTextFormat(Qt::RichText);
    //    QString text =
//            QString("<a href=\"null\">%1</a> <img src=\"redo24_h.gif\"> ").arg(name);

//    qDebug() << tr("ScoreCardTreeWidget::setBranch text=%1").arg(text);

    headerLabel->setText(text);
    headerLabel->setMinimumWidth(headerLabel->sizeHint().width());
    headerLabel->setMinimumHeight(20);
}

void ScoreCardTreeWidget::headerlabelClick(QString)
{
    emit showOrgStruct(true);
}
