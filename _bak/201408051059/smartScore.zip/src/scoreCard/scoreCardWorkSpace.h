#ifndef SCORECARDWORKSPACE_H
#define SCORECARDWORKSPACE_H

#include <QWidget>

class QSplitter;
class OrgStructWidget;

class ScoreCardWorkSpace : public QWidget
{
    Q_OBJECT
public:
    explicit ScoreCardWorkSpace(QWidget *parent = 0);
    ~ScoreCardWorkSpace();
    
signals:
    
public slots:

private:
    QWidget *nullWidget;
    QSplitter *splitter;
    OrgStructWidget *orgStructWidget;
    
};

#endif // SCORECARDWORKSPACE_H
