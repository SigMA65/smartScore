#include "scoreCardWorkSpace.h"

#include <QtGui>
#include "../orgStruct/orgStructWidget.h"

ScoreCardWorkSpace::ScoreCardWorkSpace(QWidget *parent) :
    QWidget(parent)
{

    splitter = 0;
    orgStructWidget = 0;
    nullWidget = new QWidget;

    splitter = new QSplitter();
    orgStructWidget = new OrgStructWidget(this);

    splitter->addWidget(orgStructWidget);
    splitter->addWidget(nullWidget);
//    splitter->addWidget(new QPushButton("1111", this));
//    splitter->addWidget(new QPushButton("2222", this));
    splitter->setStretchFactor(1,1);

    QVBoxLayout *l = new QVBoxLayout;
    l->addWidget(splitter);
    this->setLayout(l);

}

ScoreCardWorkSpace::~ScoreCardWorkSpace()
{
    qDebug() << "ScoreCardWorkSpace::~ScoreCardWorkSpace() START";
//    qDebug() << "ScoreCardWorkSpace::~ScoreCardWorkSpace() orgStructWidget="
//             << orgStructWidget;

//    delete splitter;
    qDebug() << "ScoreCardWorkSpace::~ScoreCardWorkSpace() END";
}
